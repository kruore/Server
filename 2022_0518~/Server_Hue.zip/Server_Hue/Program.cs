﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Server_Hue
{
    class GameSession : Session
    {
        public override void OnConnected(EndPoint endPoint)
        {
            Console.WriteLine($"OnConnected : {endPoint}");
            byte[] sendBuff = Encoding.UTF8.GetBytes("#4");
            Send(sendBuff);

            Thread.Sleep(1000);
            Disconnect();
        }
        public override void OnSend(int numOfBytes)
        {
            Console.WriteLine($"Trasnferred bytes : {numOfBytes}");
        }
        public override void OnRecv(ArraySegment<byte> buffer)
        {
            string recvData = Encoding.UTF8.GetString(buffer.Array, buffer.Offset, buffer.Count);
            Console.WriteLine($"[From Client]{recvData}");
        }
        public override void OnDisconnect(EndPoint endPoint)
        {
            Console.WriteLine($" OnDisconnected {endPoint}");
        }
    }

    class program
    {
        static Listener listener = new Listener();
      
        static void Main(string[] args)
        {

            Socket socket;
            string host = Dns.GetHostName();
            IPHostEntry ipHost = Dns.GetHostEntry(host);
            // IPAddress ipAddr = ipHost.AddressList[0];
            IPAddress iPAddr = IPAddress.Any;
            IPEndPoint ipEnd = new IPEndPoint(iPAddr, 4545);
            Console.WriteLine(ipEnd);
            Connecter connecter = new Connecter();
            listener.Init(ipEnd, () => { return new GameSession(); }, 10);

            try
            {
                Console.WriteLine("Listening...");
                while (true)
                {
                    ;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e}");
            }

        }


    }
}
