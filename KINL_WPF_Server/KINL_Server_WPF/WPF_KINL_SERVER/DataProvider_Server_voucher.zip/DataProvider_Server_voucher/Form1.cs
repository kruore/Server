﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace DataProvider_Server_voucher
{
    public partial class Form1 : Form
    {
        object lockObj = new object();
        private ObservableCollection<string> DeviceData = new ObservableCollection<string>();
        private ObservableCollection<string> IPhoneData = new ObservableCollection<string>();
        private ObservableCollection<string> WatchData = new ObservableCollection<string>();


        Task conntectCheckThread = null;

        private bool DeviceSend = false;

        public Form1()
        {
            InitializeComponent();
            MainServerStart();
            ClientManager.messageParsingAction += MessageParsing;
            ClientManager.ChangeListViewAction += ChangeListView;
            conntectCheckThread = new Task(ConnectCheckLoop);
            conntectCheckThread.Start();
        }
        private void ConnectCheckLoop()
        {
            while (true)
            {
                foreach (var item in ClientManager.clientDic)
                {
                    try
                    {
                        string sendStringData = "<TEST>";
                        byte[] sendByteData = new byte[sendStringData.Length];
                        sendByteData = Encoding.Default.GetBytes(sendStringData);
                        item.Value.tcpClient.GetStream().Write(sendByteData, 0, sendByteData.Length);
                    }
                    catch (Exception e)
                    {
                        RemoveClient(item.Value);
                        Console.WriteLine($"SAVED : {DeviceData.Count}");
                        Console.WriteLine($"Client :{item.Value.clientName}");
                        GM_DataRecorder.instance.MakeFolder(item.Value.clientName);
                        for (int i = 0; i < DeviceData.Count; i++)
                        {
                            GM_DataRecorder.instance.Enqueue_Data(DeviceData[i].ToString());
                        }
                        if (DeviceData.Count > 0)
                        {
                            GM_DataRecorder.instance.WriteSteamingData_Batch_Device();
                        }
                        DeviceData.Clear();

                    }
                }
                Thread.Sleep(1000);
            }
        }

        private void RemoveClient(ClientData targetClient)
        {
            ClientData result = null;
            ClientManager.clientDic.TryRemove(targetClient.clientNumber, out result);
            string leaveLog = string.Format("[{0}] {1} Leave Server", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), result.clientName);
            //ChangeListView(leaveLog, StaticDefine.ADD_ACCESS_LIST);
            ChangeListView(result.clientName, StaticDefine.REMOVE_USER_LIST, null);
            Console.WriteLine(leaveLog);
        }

        private void MessageParsing(string sender, string message)
        {
            lock (lockObj)
            {
                List<string> msgList = new List<string>();
                string[] msgArray = message.Split(';');
                foreach (var item in msgArray)
                {
                    if (string.IsNullOrEmpty(item))
                        continue;
                    msgList.Add(item);
                }
                SendMsgToClient(msgList, sender);
            }
        }
        private void SendMsgToClient(List<string> msgList, string sender)
        {
            string parsedMessage = "";
            string receiver = "";

            //%^& DEVICE = Connect
            //DEVCIE,TIME,DATA
            foreach (var item in msgList)
            {
                string[] splitedMsg = item.Split(',');

                //if(splitedMsg.Length < 3)
                //{
                //    return;
                //}
                receiver = splitedMsg[0];
                parsedMessage = string.Format("{0}<{1}>", sender, splitedMsg[1]);
                if (receiver.Contains("DEVICE"))
                {
                    foreach (var el in splitedMsg)
                    {
                        if (string.IsNullOrEmpty(el))
                            continue;
                        if (splitedMsg.Length < 3)
                        {
                            return;
                        }
                        string groupLogMessage = string.Format(@"[{0}],[{1}],[{2}],[{3}].[{4}]", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), splitedMsg[0], splitedMsg[1], splitedMsg[2], splitedMsg[3]);
                        ChangeListView(receiver, StaticDefine.DATA_SEND_START, groupLogMessage);
                    }
                    return;
                }
                if (receiver.Contains("IPHONE"))
                {
                    string[] groupSplit = receiver.Split(',');

                    foreach (var el in groupSplit)
                    {
                        if (string.IsNullOrEmpty(el))
                            continue;
                        string groupLogMessage = string.Format(@"[{0}] [{1}] -> [{2}] , {3}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), groupSplit[0], el, splitedMsg[1]);
                        ChangeListView(groupLogMessage, StaticDefine.ADD_USER, null);

                    }
                    return;
                }
                if (receiver.Contains("WATCH"))
                {
                    string[] groupSplit = receiver.Split(',');

                    foreach (var el in groupSplit)
                    {
                        if (string.IsNullOrEmpty(el))
                            continue;
                        string groupLogMessage = string.Format(@"[{0}] [{1}] -> [{2}] , {3}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), groupSplit[0], el, splitedMsg[1]);
                        ChangeListView(groupLogMessage, StaticDefine.ADD_USER, null);
                    }
                    return;
                }
            }
        }

        private int GetClinetNumber(string targetClientName)
        {
            foreach (var item in ClientManager.clientDic)
            {
                if (item.Value.clientName == targetClientName)
                {
                    return item.Value.clientNumber;
                }
            }
            return -1;
        }

        private void ChangeListView(string a, int b, string c)
        {
            switch (a)
            {
                case "DEVICE":
                    if (b == StaticDefine.ADD_USER)
                    {
                        listBox1.BeginInvoke((Action)(() =>
                        {
                            listBox1.Items.Add(a + "Connect");
                        }));
                    }
                    if (b == StaticDefine.REMOVE_USER_LIST)
                    {
                        listBox1.BeginInvoke((Action)(() =>
                        {
                            listBox1.Items.Add(a + "Disconnect");
                        }));
                    }
                    if (b == StaticDefine.DATA_SEND_START)
                    {
                        if (DeviceSend)
                        {
                            DeviceData.Add(c);
                            Console.WriteLine("DATAADD");
                        }
                        else
                        {
                            listBox1.BeginInvoke((Action)(() =>
                            {
                                listBox1.Items.Add(a + "Send");
                            }));
                            DeviceSend = true;
                        }
                    }
                    if (a == "Watch")
                    {
                        listBox3.BeginInvoke((Action)(() =>
                        {
                            listBox3.Items.Add(a);
                        }));
                    }
                    break;
            }
        }
        private void SaveFile()
        {
            for (int i = 0; i < DeviceData.Count; i++)
            {


            }

            for (int j = 0; j < IPhoneData.Count; j++)
            {
                // TODO: FileDialog Save

            }

            for (int z = 0; z < WatchData.Count; z++)
            {
                // TODO: FileDialog Save

            }
        }

        private void MainServerStart()
        {
            MainServer a = new MainServer();
            GM_DataRecorder b = new GM_DataRecorder();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
