﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;
public class GM_DataRecorder
{
    public static GM_DataRecorder instance = null;

    private string rootpath = string.Empty;
    private string mainfolder_Path = string.Empty;

    private string mainFolderName = "KPT_Server_DataFolder";

    private string str_DataCategory = string.Empty;


    public Queue<string> Queue_Device = new Queue<string>();

    public GM_DataRecorder()
    {
        if (instance == null)
        {
            instance = this;
        }
        mainfolder_Path = rootpath = Directory.GetCurrentDirectory();
        mainfolder_Path = MakeFolder(mainFolderName);
    }
    public void Enqueue_Data(string _Queue)
    {
        Queue_Device.Enqueue(_Queue);
    }
    bool isCategoryPrinted_SW = false;
    public bool WriteSteamingData_Batch_Device()
    {
        bool tempb = false;
        
        try
        {
            string tempFileName = "DEVICE" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            string file_Location = System.IO.Path.Combine(mainfolder_Path, tempFileName);

            string m_str_DataCategory = string.Empty;

            int totalCountoftheQueue = Queue_Device.Count;

            //Debug.Log("Saving Data Starts. Queue Count : " + totalCountoftheQueue);

            using (StreamWriter streamWriter = File.AppendText(file_Location))
            {
                while (Queue_Device.Count != 0)
                {
                    for (int i = 0; i < totalCountoftheQueue; i++)
                    {
                        string stringData = Queue_Device.Dequeue();

                        if (stringData.Length > 0)
                        {
                            if (!isCategoryPrinted_SW)
                            {
                                str_DataCategory =
                                    "TimeStamp,"
                                    + "Data";
                                streamWriter.WriteLine(str_DataCategory);
                                isCategoryPrinted_SW = true;
                            }
                            streamWriter.WriteLine(stringData);
                        }
                    }
                }
            }
            tempb = true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }
        return tempb;
    }
    private void OnDisable()
    {
        DisposeFileReader();
        //Directory.SetCurrentDirectory(rootpath);
    }
    private StreamReader fileReader = null;

    public void Start_Load_csvData(string _AccountName)
    {
        string file_Location = System.IO.Path.Combine(mainfolder_Path, _AccountName);
        string[] fileNames = Directory.GetFiles(file_Location);
        fileReader = new StreamReader(fileNames[fileNames.Length - 1]);
    }

    private void DisposeFileReader()
    {
        if (fileReader != null)
        {
            fileReader.Dispose();
            fileReader = null;
        }
    }

    //폴더 생성
    public string MakeFolder(string _WantedfolderName)
    {
        string finalFolderPath = string.Empty;

        finalFolderPath = System.IO.Path.Combine(mainfolder_Path, _WantedfolderName);
        // 만약 파일 패스에 존재하지 않는다면 디렉토리를 생성한다.
        Console.WriteLine(finalFolderPath);

        if (!Directory.Exists(finalFolderPath))
        {
            Directory.CreateDirectory(finalFolderPath);
        }
        return finalFolderPath;

    }
}